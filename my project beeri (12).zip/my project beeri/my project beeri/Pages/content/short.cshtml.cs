using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace my_project_beeri.Pages.content
{
    public class shortModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
