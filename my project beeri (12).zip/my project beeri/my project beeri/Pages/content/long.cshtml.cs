using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace my_project_beeri.Pages.content
{
    public class longModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
